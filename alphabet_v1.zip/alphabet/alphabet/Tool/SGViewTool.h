//
//  SGViewTool.h
//  SuJi
//
//  Created by beyond on 16/7/14.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface SGViewTool : NSObject
+(UIImage *)createImageWithColor:(UIColor*) color;
@end
