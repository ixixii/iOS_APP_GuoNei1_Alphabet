//
//  SecondViewController.m
//  alphabet
//
//  Created by beyond on 2020/03/10.
//  Copyright © 2020 Christine. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
