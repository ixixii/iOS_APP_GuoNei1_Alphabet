//
//  FirstViewController.m
//  alphabet
//
//  Created by beyond on 2020/03/10.
//  Copyright © 2020 Christine. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
