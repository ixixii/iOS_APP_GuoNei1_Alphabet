//
//  SceneDelegate.h
//  alphabet
//
//  Created by beyond on 2020/03/10.
//  Copyright © 2020 Christine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

