//
//  CustomButton.h
//  SuJi
//
//  Created by beyond on 16/7/10.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGViewTool.h"

@interface CustomButton : UIButton

@end
