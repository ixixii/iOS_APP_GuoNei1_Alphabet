//
//  Created by beyond on 16/9/10.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import "AlphaModel.h"

@interface HanYuAlphaModel : AlphaModel

@property (nonatomic,copy) NSString *roma;
@property (nonatomic,copy) NSString *roma_mp3;
@property (nonatomic,copy) NSString *word;
@property (nonatomic,copy) NSString *readTip;
@property (nonatomic,copy) NSString *remark;
@property (nonatomic,copy) NSString *index;

@end
