//
//  AlphaModel.h

//
//  Created by beyond on 16/9/10.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlphaModel : NSObject

@property (nonatomic,copy) NSString *alpha;

@property (nonatomic,copy) NSString *alpha_mp3;
@property (nonatomic,copy) NSString *alpha_remark;

@property (nonatomic,copy) NSString *menuItem1;

@property (nonatomic,copy) NSString *menuItem2;

@property (nonatomic,copy) NSString *menuItem3;

@property (nonatomic,copy) NSString *menuItem4;


@property (nonatomic,copy) NSString *hongBaoTopStr;
@property (nonatomic,copy) NSString *hongBaoMiddleStr;
@property (nonatomic,copy) NSString *hongBaoBottomStr;

@property (nonatomic,copy) NSString *hongBaoImgLocalName;
@property (nonatomic,copy) NSString *hongBaoImgWebName;
@end
