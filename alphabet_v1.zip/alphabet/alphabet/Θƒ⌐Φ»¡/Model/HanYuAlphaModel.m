//
//  Created by beyond on 16/9/10.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import "HanYuAlphaModel.h"

@implementation HanYuAlphaModel
- (NSString *)alpha
{
    return _roma;
}

- (NSString *)alpha_mp3
{
    return @"";
}
- (NSString *)alpha_remark
{
    return @"";
}
- (NSString *)menuItem1
{
    return _roma;
}
- (NSString *)menuItem2
{
    return @"";
}
- (NSString *)menuItem3
{
    return @"";
}
- (NSString *)menuItem4
{
    return @"";
}
- (NSString *)hongBaoTopStr
{
    return _roma;
}
- (NSString *)hongBaoMiddleStr
{
    return _roma;
}
- (NSString *)hongBaoBottomStr
{
    return @"korean alpha";
}
@end
