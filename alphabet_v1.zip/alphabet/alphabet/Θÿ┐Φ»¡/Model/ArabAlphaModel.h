//
//  ArabAlphaModel.h
//
//  Created by beyond on 16/9/10.
//  Copyright © 2016年 beyond. All rights reserved.
//

#import "AlphaModel.h"

@interface ArabAlphaModel : AlphaModel



// 读法
@property (nonatomic,copy) NSString *read;
//
@property (nonatomic,copy) NSString *name;
//
@property (nonatomic,copy) NSString *tail;
//
@property (nonatomic,copy) NSString *middle;
//
@property (nonatomic,copy) NSString *head;
//
@property (nonatomic,copy) NSString *remark;

@end
