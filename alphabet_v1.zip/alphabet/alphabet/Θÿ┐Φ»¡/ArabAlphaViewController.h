//
//  ViewController.h
//  arabalpha
//
//  Created by beyond on 2020/02/27.
//  Copyright © 2020 Christine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArabAlphaViewController : UIViewController


@end

